package com.apollo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {

    static {
        System.loadLibrary("apollo");
    }

    public native String runInference(String prompt);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        TextView tv = new TextView(this);
        tv.setText(runInference("Hello Apollo"));
        setContentView(tv);
    }
}
