#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_apollo_MainActivity_runInference(JNIEnv* env, jobject, jstring prompt) {

    const char* input = env->GetStringUTFChars(prompt, 0);

    std::string response = "Apollo LLM running locally: ";
    response += input;

    env->ReleaseStringUTFChars(prompt, input);

    return env->NewStringUTF(response.c_str());
}
